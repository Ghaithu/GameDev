﻿//using Microsoft.Xna.Framework;
//using Microsoft.Xna.Framework.Graphics;
//using Microsoft.Xna.Framework.Input;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using MovingSprites.Managers;
//using MovingSprites.Models;

//namespace MovingSprites.Sprites
//{
//    public class Sprite
//    {
//        #region Fields

//        protected AnimationManager _animationManager;

//        protected Dictionary<string, Animation> _animations;

//        protected Vector2 _position;

//        protected Texture2D _texture;
//        private Rectangle rectangle;

//        protected bool hasJumped = false;

//        #endregion

//        #region Properties

//        public Input Input;


//        public Vector2 Position
//        {
//            get { return _position; }
//            set
//            {
//                _position = value;

//                if (_animationManager != null)
//                    _animationManager.Position = _position;
//            }
//        }

//        public float Speed = 1f;

//        public Vector2 Velocity;



//        #endregion

//        #region Methods

//        public virtual void Draw(SpriteBatch spriteBatch)
//        {
//            if (_texture != null)
//                spriteBatch.Draw(_texture, Position, rectangle, Color.White);
//            else if (_animationManager != null)
//                _animationManager.Draw(spriteBatch);
//            else throw new Exception("This ain't right..!");
//        }

//        public Sprite(Texture2D texture, Vector2 newpos)
//        {
//            _texture = texture;
//            _position = newpos;
//            hasJumped = true;
//        }

//        public virtual void Move()
//        {
//            Speed = 4;
//            if (Keyboard.GetState().IsKeyDown(Input.Left))
//                Velocity.X = -Speed;
//            else if (Keyboard.GetState().IsKeyDown(Input.Right))
//                Velocity.X = Speed;
//        }

//        // float Bleedoff = 1.0f;
//        //readonly Vector2 gravity = new Vector2(0, -9.8f);

//        public virtual void Jump()
//        {

//            //float time = (float)gameTime.ElapsedGameTime.TotalSeconds;

//            if (Keyboard.GetState().IsKeyDown(Input.Space))
//            {
//                _position.Y -= 10f;
//                Velocity.Y = -5;

//                hasJumped = true;




//            }

//            if (hasJumped == true)
//            {
//                float i = 1;
//                Velocity.Y += 5;



//            }



//            if (_position.Y >= 350)
//            {
//                hasJumped = false;
//            }

//            if (hasJumped == false)
//            {
//                Velocity.Y = 0f;
//            }
//        }

//        protected virtual void SetAnimations()
//        {
//            if (Velocity.X > 0)
//                _animationManager.Play(_animations["WalkRight"]);
//            else if (Velocity.X < 0)
//                _animationManager.Play(_animations["WalkLeft"]);


//            else _animationManager.Stop();
//        }

//        public Sprite(Dictionary<string, Animation> animations)
//        {
//            _animations = animations;
//            _animationManager = new AnimationManager(_animations.First().Value);
//        }



//        public virtual void Update(GameTime gameTime, List<Sprite> sprites)
//        {
//            rectangle = new Rectangle((int)_position.X, (int)_position.Y, _texture.Width, _texture.Height);

//            Move();
//            Jump();

//            SetAnimations();

//            _animationManager.Update(gameTime);

//            Position += Velocity;
//            Velocity = Vector2.Zero;
//        }

//        public void Collision(Rectangle newrect, int xOffset, int yOffset)
//        {
//            if (rectangle.touchTopOf(newrect))
//            {
//                rectangle.Y = newrect.Y - rectangle.Height;
//                Velocity.Y = 0f;
//                hasJumped = false;
//            }

//            if (rectangle.touchLeftof(newrect))
//            {
//                _position.X = newrect.X - rectangle.Width - 2;

//            }

//            if (rectangle.touchRightof(newrect))

//            {
//                _position.X = newrect.X + newrect.Width + 2;

//            }
//            if (rectangle.touchBottomOf(newrect))
//            {
//                Velocity.Y = 1f;

//            }

//            if (_position.X < 0) _position.X = 0;
//            if (_position.X > xOffset - rectangle.Width) _position.X = xOffset - rectangle.Width;
//            if (_position.Y < 0) Velocity.Y = 1f;
//            if (_position.Y > yOffset - rectangle.Height) _position.Y = yOffset - rectangle.Height;

//        }


//        #endregion
//    }
//}
