﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;
using MovingSprites.Models;

using MovingSprites.Map;


namespace MovingSprites
{
    
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        Player player;
        Player player2;
       // private List<Sprite> _sprites;
        Map.Map map;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        
        protected override void Initialize()
        {
           
            map = new Map.Map();
            player = new Player();
            

            base.Initialize();
        }

        
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.

            spriteBatch = new SpriteBatch(GraphicsDevice);
            player.Load(Content);
            Map.TileMap.Content = Content;
            map.Generate(new int[,]
            {
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,1,0,0,0,1,0,0,0,0,0},

                /* {2,1,1,1,1,1,1,1,1,1,1,1,1,1},
                {2,2,2,2,2,2,2,2,1,1,1,1,1,1}
                */

            }, 64);

            #region OldCode
            // NOTE: I no-longer use this reference as it affects different objects if being used multiple times!
            //      var animations = new Dictionary<string, Animation>()
            //{

            //  { "WalkLeft", new Animation(Content.Load<Texture2D>("Player/WalkingLeft"), 5) },
            //  { "WalkRight", new Animation(Content.Load<Texture2D>("Player/WalkingRight"), 5) },
            //};

            //      _sprites = new List<Sprite>()
            //{
            //  new Sprite(new Dictionary<string, Animation>()
            //  {

            //    { "WalkLeft", new Animation(Content.Load<Texture2D>("Player/WalkingLeft"), 5) },
            //    { "WalkRight", new Animation(Content.Load<Texture2D>("Player/WalkingRight"), 5) },

            //  }
            //  )
            //  {
            //    Position = new Vector2(50,350),
            //    Input = new Input()
            //    {
            //      Left = Keys.A,
            //      Right = Keys.D,
            //      Space = Keys.Space,
            //    },
            //  },

            //};
            #endregion
        }


        protected override void UnloadContent()
        {
            
        }

       
        protected override void Update(GameTime gameTime)
        {
            player.Update(gameTime);
            //foreach (var sprite in _sprites)
            //sprite.Update(gameTime, _sprites);
            foreach (CollisionTiles tile in map.CollisionTiles)
                player.Collision(tile.Rect, map.Width, map.Height);
                

            base.Update(gameTime);
        }

       
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            spriteBatch.Begin();
            map.Draw(spriteBatch);
            player.Draw(gameTime,spriteBatch);
            //foreach (var sprite in _sprites)
            //    sprite.Draw(spriteBatch);

            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
