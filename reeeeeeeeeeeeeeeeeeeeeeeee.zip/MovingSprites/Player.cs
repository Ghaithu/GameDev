﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using MovingSprites.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace MovingSprites
{
    class Player
    {
        AnimationPlayer animationplayer;
        Animation walkAnimation;
        Animation idleAnimationLeft;
        Animation idleAnimationRight;
        private Rectangle rectangle;
        Vector2 velocity;
        Vector2 position = new Vector2(400,200);
        float speed = 1f;
        private bool hasJumped;
        private bool isFacingLeft = true;
        private bool isFacingRight = true;
       
        
        public Player()
        {
            

        }
        

        public void Load(ContentManager Content)
        {
            
            walkAnimation = new Animation(Content.Load<Texture2D>("Walk"), 95, 0.1f, true);
            idleAnimationLeft = new Animation(Content.Load<Texture2D>("Idle2"), 80, 0.3f, true);
            idleAnimationRight = new Animation(Content.Load<Texture2D>("IdleRight"), 85, 0.3f, true);

        }

        public virtual void Jump()
        {

            //float time = (float)gameTime.ElapsedGameTime.TotalSeconds;

            if (Keyboard.GetState().IsKeyDown(Keys.Space) /*&& hasJumped == false*/)
            {
                position.Y -= 10f;
                velocity.Y = -6;

                hasJumped = true;




            }

            if (hasJumped == true)
            {
                float i = 1;
                velocity.Y += 0.2f * i;



            }


            if (position.Y >= 550 )
            {
                hasJumped = false;
                position.Y = 475;
            }

            if (hasJumped == false)
            {
                velocity.Y = 0f;
            }
        }

        public void Update(GameTime gameTime)
        {
            if(position.Y >= 600)
            {
                velocity.Y = 0;
            }
            rectangle = new Rectangle((int)position.X, (int)position.Y, 125,125);
            speed = 4;
            Jump();
            position += velocity;
            if (Keyboard.GetState().IsKeyDown(Keys.D))
            {
                isFacingLeft = false;
                velocity.X = speed;
                isFacingRight = true;
            }
            else
                velocity.X = 0;
               
            

            if (Keyboard.GetState().IsKeyDown(Keys.A))
            {
                isFacingRight = false;
                velocity.X = -speed;
                isFacingLeft = true;
            }

            if (velocity.X != 0)
                animationplayer.PlayAnimation(walkAnimation);
            else if (velocity.X == 0 && isFacingLeft == true)
                animationplayer.PlayAnimation(idleAnimationLeft);
            else if (velocity.X == 0 && isFacingRight == true)
                animationplayer.PlayAnimation(idleAnimationRight);
            
        }

        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            SpriteEffects flip = SpriteEffects.None;

            if (velocity.X >= 0)
                flip = SpriteEffects.None;
            else if (velocity.X < 0)
                flip = SpriteEffects.FlipHorizontally;
    
  

            animationplayer.Draw(gameTime, spriteBatch, position, flip);
        }

        public void Collision(Rectangle newrect, int xOffset, int yOffset)
        {
            if (rectangle.touchTopOf(newrect))
            {
                rectangle.Y = newrect.Y - rectangle.Height -5;
                velocity.Y = 2f;
                hasJumped = false;
            }

            if (rectangle.touchLeftof(newrect))
            {
                position.X = newrect.X - rectangle.Width -2;

            }

            if (rectangle.touchRightof(newrect))

            {
                position.X = newrect.X + newrect.Width + 2;

            }
            if (rectangle.touchBottomOf(newrect))
            {
                velocity.Y = 1f;

            }

            if (position.X < 0) position.X = 0;
            if (position.X > xOffset - rectangle.Width) position.X = xOffset - rectangle.Width;
            if (position.Y < 0) velocity.Y = 1f;
            if (position.Y > yOffset - rectangle.Height) position.Y = yOffset - rectangle.Height;

        }
    }
}
